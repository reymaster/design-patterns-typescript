import { DatabaseSingleton } from './DatabaseSingleton';

function runSingleton() {
  const employee = DatabaseSingleton.instance;
  employee.add({ name: 'Luiz', role: 'Director' });
  employee.add({ name: 'Maria', role: 'Manager' });
  employee.add({ name: 'Eduardo', role: 'Office Boy' });

  employee.show();
}

runSingleton();
