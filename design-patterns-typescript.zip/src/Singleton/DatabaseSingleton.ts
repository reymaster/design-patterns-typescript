import { Person } from './interfaces/Person';

export class DatabaseSingleton {
  private static _instance: DatabaseSingleton | null = null;
  private users: Person[] = [];

  private constructor() {
    //
  }

  static get instance(): DatabaseSingleton {
    if (DatabaseSingleton._instance === null) {
      DatabaseSingleton._instance = new DatabaseSingleton();
    }

    return DatabaseSingleton._instance;
  }

  add(user: Person): void {
    this.users.push(user);
  }

  remove(index: number): void {
    this.users.splice(index, 1);
  }

  show(): void {
    for (const user of this.users) {
      console.log(user);
    }
  }
}
