export interface Person {
  name: string;
  role: string;
}
