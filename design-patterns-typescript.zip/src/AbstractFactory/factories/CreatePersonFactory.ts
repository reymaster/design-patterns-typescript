import CreateEmployee from '../CreateEmployee';
import CreateVendor from '../CreateVendor';
import AbstractEmployee from '../interfaces/AbstractEmployee';
import AbstractVendor from '../interfaces/AbstractVendor';
import CreatePersonAbstractFactory from '../interfaces/CreatePersonAbstractFactory';

export default class CreatePersonFactory implements CreatePersonAbstractFactory {
  createEmployee(name: string, role: string): AbstractEmployee {
    return new CreateEmployee(name, role);
  }
  createVendor(name: string, role: string, comission: number): AbstractVendor {
    return new CreateVendor(name, role, comission);
  }
}
