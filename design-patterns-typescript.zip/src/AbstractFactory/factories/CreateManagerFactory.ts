import CreateEmployeeManager from '../CreateEmployeeManager';
import CreateVendorManager from '../CreateVendorManager';
import AbstractEmployee from '../interfaces/AbstractEmployee';
import AbstractVendor from '../interfaces/AbstractVendor';
import CreatePersonAbstractFactory from '../interfaces/CreatePersonAbstractFactory';

export default class CreateManagerFactory implements CreatePersonAbstractFactory {
  createEmployee(name: string, role: string): AbstractEmployee {
    return new CreateEmployeeManager(name, role);
  }
  createVendor(name: string, role: string, comission: number): AbstractVendor {
    return new CreateVendorManager(name, role, comission);
  }
}
