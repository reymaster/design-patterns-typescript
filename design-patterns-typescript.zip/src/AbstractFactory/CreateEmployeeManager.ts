import AbstractEmployee from './interfaces/AbstractEmployee';

export default class CreateEmployeeManager implements AbstractEmployee {
  name: string;
  role: string;

  constructor(name: string, role: string) {
    this.name = name;
    this.role = role;
  }
  greeting(): string {
    return `Oi, sou um gerente, minha função é ${this.role} e meu nome é ${this.name}`;
  }
}
