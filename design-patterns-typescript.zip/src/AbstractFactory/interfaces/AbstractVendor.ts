export default interface AbstractVendor {
  greeting(): string;
}
