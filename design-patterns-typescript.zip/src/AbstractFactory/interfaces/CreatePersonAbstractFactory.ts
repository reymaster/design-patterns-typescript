import AbstractEmployee from './AbstractEmployee';
import AbstractVendor from './AbstractVendor';

/**
 * A interface Abstract Factory declara um conjunto de métodos que retornam
 * diferentes produtos abstratos. Esses produtos são chamados de família e são
 * relacionado por um tema ou conceito de alto nível. Produtos de uma família geralmente são
 * capazes de colaborar entre si. Uma família de produtos pode ter múltiplos
 * variantes, mas os produtos de uma variante são incompatíveis com produtos de
 * outra variante.
 */

export default interface CreatePersonAbstractFactory {
  createEmployee(name: string, role: string): AbstractEmployee;
  createVendor(name: string, role: string, comission: number): AbstractVendor;
}
