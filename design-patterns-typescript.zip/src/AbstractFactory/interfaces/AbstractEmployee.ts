export default interface AbstractEmployee {
  greeting(): string;
}
