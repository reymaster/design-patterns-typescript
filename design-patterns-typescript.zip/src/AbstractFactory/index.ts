import CreateManagerFactory from './factories/CreateManagerFactory';
import CreatePersonFactory from './factories/CreatePersonFactory';
import CreatePersonAbstractFactory from './interfaces/CreatePersonAbstractFactory';

function runPerson(factory: CreatePersonAbstractFactory) {
  const empregado1 = factory.createEmployee('Reinaldo', 'Designer');
  const empregado2 = factory.createEmployee('Patricia', 'Supervisora');
  const vendedor1 = factory.createVendor('Leila', 'Vendedora', 5.5);

  console.log(empregado1.greeting());
  console.log(empregado2.greeting());
  console.log(vendedor1.greeting());
}

function runManager(factory: CreatePersonAbstractFactory) {
  const gerente1 = factory.createEmployee('João Marcos', 'Gerente de TI');
  const gerente2 = factory.createVendor('Maria Luiza', 'Gerente de Vendas', 25.9);

  console.log(gerente1.greeting());
  console.log(gerente2.greeting());
}

runPerson(new CreatePersonFactory());
runManager(new CreateManagerFactory());
