import AbstractVendor from './interfaces/AbstractVendor';

export default class CreateVendorManager implements AbstractVendor {
  name: string;
  role: string;
  comission: number;

  constructor(name: string, role: string, comission: number) {
    this.name = name;
    this.role = role;
    this.comission = comission;
  }
  greeting(): string {
    return `Oi, minha função é ${this.role}, meu nome é ${this.name} e ganho ${this.comission}% de comissão.`;
  }
}
